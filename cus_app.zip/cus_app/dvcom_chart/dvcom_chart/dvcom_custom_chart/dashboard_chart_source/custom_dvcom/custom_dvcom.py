import frappe, json
import calendar
import datetime

@frappe.whitelist()
def get(chart_name):
    chart = frappe.get_doc('Dashboard Chart', chart_name)
    filters = frappe.parse_json(chart.filters_json)
    
    result = {}
    q_filters = {}
    sales_persons = []

    from_date = datetime.datetime.today().replace(day=1)
    to_date = last_day(from_date)
    q_filters['docstatus'] = ["=", 1]

    if filters.doctype == 'Sales Invoice':
        q_filters['posting_date'] = ["between", [from_date, to_date]]
    elif filters.doctype in ('Sales Order', 'Quotation'):
        q_filters['transaction_date'] = ["between", [from_date, to_date]]
    sales_persons = frappe.db.get_list(filters.doctype, filters = q_filters)

    if filters.type == 'Amount':
        for row in sales_persons:
            doc = frappe.get_doc(filters.doctype, row.name)
            if doc.sales_person:
                allocated_amount = doc.base_net_total
                if doc.sales_person in result.keys():
                    result[doc.sales_person] += allocated_amount
                else:
                    result[doc.sales_person] = allocated_amount

    elif filters.type == 'Count':
        for row in sales_persons:
            doc = frappe.get_doc(filters.doctype, row.name)
            if doc.sales_person:
                if doc.sales_person in result.keys():
                    result[doc.sales_person] += 1
                else:
                    result[doc.sales_person] = 1

    return {
        "labels": [row for row in result],
        "datasets": [{
            "values": [result[row] for row in result]
        }]
    }

def last_day(date):
    next_month = date.replace(day=28) + datetime.timedelta(days=4)
    return next_month - datetime.timedelta(days=next_month.day)
frappe.provide('frappe.dashboards.chart_sources');

frappe.dashboards.chart_sources["Custom DVCOM"] = {
	method: "dvcom_chart.dvcom_custom_chart.dashboard_chart_source.custom_dvcom.custom_dvcom.get",
	filters: [
        {
            fieldname: "company",
			label: __("Company"),
			fieldtype: "Link",
			options: "Company",
			default: frappe.defaults.get_user_default("Company"),
			reqd: 1
        },
        {
            fieldname: "doctype",
            label: __("DocType"),
            fieldtype: "Select",
            options: ["Sales Invoice", "Sales Order", "Quotation"],
            reqd: 1
        },
        {
            fieldname: "type",
            label: __("Type"),
            fieldtype: "Select",
            options: ["Count", "Amount"],
            reqd: 1
        },
	]
};
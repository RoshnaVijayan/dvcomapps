import frappe, json
import calendar
from frappe import _
from frappe.utils import datetime, get_datetime_str, add_months, getdate, get_datetime_str
from frappe.utils import flt

@frappe.whitelist()
def get(chart_name):
    chart = frappe.get_doc('Dashboard Chart', chart_name)
    filters = frappe.parse_json(chart.filters_json)
    
    result = {}
    sales_persons = []
    doctype, from_date, to_date = '', None, None
    if filters.doctype:
        doctype = filters.doctype

    '''
    Get start and end date of current month
    Get required DocTypes within those dates
    Get all records of a specific sales_person specified in filter
    Get required DocTypes against these records within current month 
    Get accumulated allocated_amount of sales_person against every customer
    '''
    date = datetime.datetime.today()
    from_date = getdate(date.replace(day = 1))
    to_date = getdate(date)
    
    sales_persons = frappe.db.get_list('Sales Team',{
        'sales_person': filters.sales_person,
        'parenttype': doctype},['parent','name'])
    for row in sales_persons:
        doclist = frappe.db.get_list(doctype,
        filters =  {'transaction_date': ["between", [from_date, to_date]],
                    'name': row.parent},
        fields = ['name'])
        if doclist:
            doc = frappe.get_doc(doctype,doclist[0].name)
            for person in doc.sales_team:
                if person.name == row.name:
                    allocated_amount = person.allocated_amount
                    # if filters.currency:
                    #     allocated_amount = flt(
                    #     doc.base_net_total * person.allocated_percentage / 100.0,
                    #     doc.precision("allocated_amount", person))
                    if doc.party_name in result.keys():
                        result[doc.party_name] += allocated_amount
                    else:
                        result[doc.party_name] = allocated_amount
    return {
        "labels": [row for row in result],
        "datasets": [{
            "values": [result[row] for row in result]
        }]
    }
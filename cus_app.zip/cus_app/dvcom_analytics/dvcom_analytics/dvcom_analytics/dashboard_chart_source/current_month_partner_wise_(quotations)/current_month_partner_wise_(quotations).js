frappe.provide('frappe.dashboards.chart_sources');

frappe.dashboards.chart_sources["Current Month Partner wise (Quotations)"] = {
	method: "dvcom_analytics.dvcom_analytics.dashboard_chart_source.current_month_partner_wise_(quotations).current_month_partner_wise_(quotations).get",
	filters: [
        {
            fieldname: "company",
			label: __("Company"),
			fieldtype: "Link",
			options: "Company",
			default: frappe.defaults.get_user_default("Company"),
			reqd: 1
        },
        {
            fieldname: "doctype",
            label: __("DocType"),
            fieldtype: "Link",
            options: "DocType"
        },
        {
            fieldname: "currency",
            label: __("Company Currency"),
            fieldtype: "Check"
        },
        {
            fieldname: "sales_person",
			label: __("Sales Person"),
			fieldtype: "Link",
			options: "Sales Person"
        }
	]
};
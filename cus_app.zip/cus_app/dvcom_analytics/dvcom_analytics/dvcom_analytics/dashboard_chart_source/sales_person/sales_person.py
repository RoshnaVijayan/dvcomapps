import frappe, json
import calendar
from frappe import _
from frappe.utils import datetime, get_datetime_str, add_months, getdate, get_datetime_str
from frappe.utils import flt

@frappe.whitelist()
def get(chart_name):
    chart = frappe.get_doc('Dashboard Chart', chart_name)
    filters = frappe.parse_json(chart.filters_json)
    
    result = {}
    q_filters = {}
    sales_persons = []

    '''
    Get start and end date of specified quarter
    Get required doctypes within those dates
    Get sales_team from the doctypes of resulting doctypes
    Get accumulated allocated_amount of sales_persons 
    '''

    doctype, from_date, to_date = '', None, None
    if filters.doctype:
        doctype = filters.doctype
    if filters.quarter:
        today = datetime.datetime.today()
        month = get_quarter(filters.quarter)
        month = month - today.month
        from_date, to_date = add_months(today, month), add_months(today, month+2)
        from_date, to_date = from_date.replace(day = 1), to_date.replace(day = calendar.monthrange(to_date.year, to_date.month)[1])
        from_date, to_date = getdate(from_date), getdate(to_date)
    
    if doctype == 'Sales Invoice':
        q_filters['posting_date'] = ["between", [from_date, to_date]]
    elif doctype in ('Sales Order', 'Quotation'):
        q_filters['transaction_date'] = ["between", [from_date, to_date]]
    sales_persons = frappe.db.get_list(doctype, filters = q_filters)

    for row in sales_persons:
        doc = frappe.get_doc(doctype, row.name)
        for person in doc.sales_team:
            allocated_amount = person.allocated_amount
            # if filters.currency and doc.grand_total:
            #     allocated_amount = flt(
			# 	doc.grand_total * person.allocated_percentage / 100.0,
			# 	doc.precision("allocated_amount", person))
            if person.sales_person in result.keys():
                result[person.sales_person] += allocated_amount
            else:
                result[person.sales_person] = allocated_amount

    return {
        "labels": [row for row in result],
        "datasets": [{
            "values": [result[row] for row in result]
        }]
    }

def get_quarter(quarter):
    month = 0 if quarter == 'Current' else 3
    today = datetime.datetime.today()
    if today.month > 9:
        month = 10 - month
    elif today.month > 6:
        month = 7 - month
    elif today.month > 3:
        month = 4 - month
    else:
        month = 1 - month
    if month<0:
        month = 10
    return month
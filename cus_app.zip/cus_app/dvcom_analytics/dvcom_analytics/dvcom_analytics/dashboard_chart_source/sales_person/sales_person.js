frappe.provide('frappe.dashboards.chart_sources');

frappe.dashboards.chart_sources["Sales Person"] = {
	method: "dvcom_analytics.dvcom_analytics.dashboard_chart_source.sales_person.sales_person.get",
	filters: [
        {
            fieldname: "company",
			label: __("Company"),
			fieldtype: "Link",
			options: "Company",
			default: frappe.defaults.get_user_default("Company"),
			reqd: 1
        },
        {
            fieldname: "quarter",
			label: __("Quarter"),
			fieldtype: "Select",
			options: ["Current", "Previous"]
        },
        {
            fieldname: "doctype",
            label: __("DocType"),
            fieldtype: "Link",
            options: "DocType"
        },
        {
            fieldname: "currency",
            label: __("Company Currency"),
            fieldtype: "Check"
        }
	]
};
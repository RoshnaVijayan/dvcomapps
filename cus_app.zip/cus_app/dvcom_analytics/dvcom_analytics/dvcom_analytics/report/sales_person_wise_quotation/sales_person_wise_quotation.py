# Copyright (c) 2013, Havenir Solutions and contributors
# For license information, please see license.txt

from __future__ import unicode_literals
import frappe
from frappe import _

def execute(filters=None):
	columns, data = [], []
	columns = [
		{
			'label': 'Transaction Date',
			'fieldname': 'transaction_date',
			'fieldtype': 'Date'
		},
		{
			'label': 'Customer',
			'fieldname': 'party_name',
			'fieldtype': 'Link',
			'options': 'Customer',
			'width': '100'
		},
		{
			'label': 'Sales Person',
			'fieldname': 'sales_person',
			'fieldtype': 'Link',
			'options': 'Sales Person',
			'width': '100'
		},
		{
			'label': 'Contribution to Net Total',
			'fieldname': 'allocated_amount',
			'fieldtype': 'Data'
		},
		{
			'label': 'Quotation',
			'fieldname': 'name',
			'fieldtype': 'Link',
			'options': 'Quotation',
			'width': '130'
		}
	]
	if filters.show_item_details:
			columns.extend([
				{
					"fieldname": "item_code",
					"label": _("Item Code"),
					"fieldtype": "Link",
					"options": "Item"
				},
				{
					"fieldname": "item_description",
					"label": _("Item Description"),
					"fieldtype": "Data",	
				},
				{
					"fieldname": "qty",
					"label": _("Item Qty"),
					"fieldtype": "Float"	
				},
				{
					"fieldname": "amount",
					"label": _("Amount"),
					"fieldtype": "Float"	
				},
				{
					"fieldname": "warehouse",
					"label": _("Receiving Warehouse"),
					"fieldtype": "Link",
					"options": "Warehouse"
				}
	])
	data = get_data(filters)
	return columns, data

def get_data(filters):
	data = []
	q_filters = {}
	s_filters = {'parenttype': 'Quotation'}
	
	if filters.sales_person:
		s_filters['sales_person'] = filters.sales_person
	if filters.name:
		s_filters['parent'] = filters.name
	if filters.party_name:
		q_filters['party_name'] = filters.party_name
	if filters.from_date or filters.to_date:
		q_filters['transaction_date'] = ["between", (filters.from_date, filters.to_date)]

	doclist = frappe.db.get_list('Sales Team', s_filters, ['parent', 'sales_person', 'allocated_amount'])
	for row in doclist:
		q_filters['name'] = row.parent
		quotation = frappe.db.get_list('Quotation', q_filters, ['name'])
		if quotation:
			doc = frappe.get_doc('Quotation', quotation[0].name)
			if filters.show_item_details:
				for item in doc.items:
					data.append({
						'party_name': doc.party_name,
						'sales_person': row.sales_person,
						'allocated_amount': row.allocated_amount,
						'transaction_date': doc.transaction_date,
						'item_code': item.item_code,
						'item_description': item.description,
						'qty': item.actual_qty,
						'amount': item.rate,
						'warehouse': item.warehouse,
						'name': doc.name
					})
			else:
				data.append({
					'party_name': doc.party_name,
					'sales_person': row.sales_person,
					'allocated_amount': row.allocated_amount,
					'transaction_date': doc.transaction_date,
					'name': doc.name
				})
	return data
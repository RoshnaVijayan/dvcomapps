// Copyright (c) 2016, Havenir Solutions and contributors
// For license information, please see license.txt
/* eslint-disable */

frappe.query_reports["Sales Person Wise Quotation"] = {
	"filters": [
		{
			'label': 'Sales Person',
			'fieldname': 'sales_person',
			'fieldtype': 'Link',
			'options': 'Sales Person'
		},
		{
			'label': 'Customer',
			'fieldname': 'party_name',
			'fieldtype': 'Link',
			'options': 'Customer'
		},
		{
			'label': 'Quotation',
			'fieldname': 'name',
			'fieldtype': 'Link',
			'options': 'Quotation'
		},
		{
			'label': 'From Date',
			'fieldname': 'from_date',
			'fieldtype': 'Date',
			'default': frappe.datetime.add_months(frappe.datetime.get_today(), -1)
		},
		{
			'label': 'To Date',
			'fieldname': 'to_date',
			'fieldtype': 'Date',
			'default': frappe.datetime.get_today()
		},
		{
			"fieldname": "show_item_details",
			"label": __("Show Item Details"),
			"fieldtype": "Check",
			"default": "1",
			on_change: () => {
				$('button[data-label="Refresh"]').click();
			}
		}
	]
};
